//
//  AlarmTableViewCell.h
//  blueTooth
//
//  Created by duluyang on 15/4/25.
//  Copyright (c) 2015年 duluyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlarmTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *timeText;

@end
