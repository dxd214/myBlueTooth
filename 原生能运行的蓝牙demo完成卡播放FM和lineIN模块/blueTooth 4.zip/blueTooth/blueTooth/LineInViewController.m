//
//  LineInViewController.m
//  blueTooth
//
//  Created by duluyang on 15/4/21.
//  Copyright (c) 2015年 duluyang. All rights reserved.
//

#import "LineInViewController.h"
#import "OABlueToothManager.h"



@interface LineInViewController ()<OADelegate>

@end

@implementation LineInViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //    CMTabbarViewController *tab = (CMTabbarViewController *)self.tabBarController;
    //    [tab setTabbarHidden:YES];
    //    [_musicTableView reloadData];
    [OABlueToothManager sharedInstance].AuxManager = [[OABlueToothManager sharedInstance].bluzManager getAuxManager:self];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"LineIn";
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)lineInActioon:(id)sender {
    NSLog(@"控制Linein静音状态");
    [[OABlueToothManager sharedInstance].auxManager mute];
}

#pragma mark AuxDelegate 代理方法

-(void)managerReady:(UInt32)mode
{
    NSLog(@"AuxManager Ready");
}

-(void)stateChanged:(UInt32)state
{
    NSLog(@"stateChanged");
}

@end
