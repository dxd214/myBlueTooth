//
//  LineInViewController.h
//  blueTooth
//
//  Created by duluyang on 15/4/21.
//  Copyright (c) 2015年 duluyang. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LineInViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *lineInButton;
- (IBAction)lineInActioon:(id)sender;

@end
